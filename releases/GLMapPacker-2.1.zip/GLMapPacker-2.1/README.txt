GL Map Packer 2.1
=================

Texture toolkit for game art: Pack, Unpack, Convert (normal / height / AO),
Utility (flip and invert), Renamer and a Maya material Injector.

Requirements
------------
Windows 10 or 11 with .NET Framework 4.8 (already installed on Windows 10
version 1903 and later, and on Windows 11). Nothing to install.

Run
---
Double-click GLMapPacker.exe. You can keep it anywhere.

Maya importer (Injector)
------------------------
1. In GL Map Packer, open the Injector tab, drop your texture maps and press
   "Export preset". This writes %TEMP%\maya_bridge\material_preset.json
2. Copy Injector.py into your Maya scripts folder,
   for example Documents\maya\scripts
3. In Maya's Script Editor (Python tab) run:

       import Injector
       Injector.import_preset(assign_to_selection=True)

Full guide with screenshots:
https://github.com/Jappomo/GL_FileRenamer/blob/main/docs/TUTORIAL.md
